<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
	<head>
	<title>Engineering</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <link rel="shortcut icon" href="../favicon.ico"> 
        <link rel="stylesheet" type="text/css" href="css/demo.css" />
        <link rel="stylesheet" type="text/css" href="css/style3.css" />
		<link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
	<meta charset="utf-8">
	<link rel="icon" href="img/favicon.png" type="image/x-icon">
	<link rel="shortcut icon" href="img/favicon.png" type="image/x-icon" />
	<meta name="description" content="Your description">
	<meta name="keywords" content="Your keywords">
	<meta name="author" content="Your name">
	<link rel="stylesheet" href="css/bootstrap1.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/responsive.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300' rel='stylesheet' type='text/css'>
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/superfish.js"></script>
	<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
    <link href="css/bootstrap-responsive.css" rel="stylesheet">
    <link href="css/docs.css" rel="stylesheet">
    <link href="css/prettify.css" rel="stylesheet">
    <link href="css/tm_docs.css" rel="stylesheet">

	    
	<script type="text/javascript">if($(window).width()>1024){document.write("<"+"script src='js/jquery.preloader.js'></"+"script>");}	</script>
	<script>		
		 jQuery(window).load(function() {	
		 $x = $(window).width();		
	if($x > 1024)
	{			
	jQuery("#content .row").preloader();}	
	
	jQuery(".list-blog li:last-child").addClass("last"); 
	jQuery(".list li:last-child").addClass("last"); 

	
    jQuery('.spinner').animate({'opacity':0},1000,'easeOutCubic',function (){jQuery(this).css('display','none')});	
  		  }); 
					
	</script>

	<!--[if lt IE 8]>
  		<div style='text-align:center'><a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.com/img/upgrade.jpg"border="0"alt=""/></a></div>  
 	<![endif]-->
	<!--[if (gt IE 9)|!(IE)]><!-->
	<!--<![endif]-->
	<!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>    
    <link rel="stylesheet" href="css/ie.css" type="text/css" media="screen">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400' rel='stylesheet' type='text/css'>
  <![endif]-->
	</head>

	<body>
<div class="spinner"></div>
<!--============================== header =================================-->
<header>
      <div class="container clearfix">
    <div class="row">
          <div class="span12">
        <div class="navbar navbar_">
              <div class="container">
            <h1 class="brand brand_"><a href="index.php"><img alt="" src="img/logo.png" width="500" height="200"> </a></h1>
            <a class="btn btn-navbar btn-navbar_" data-toggle="collapse" data-target=".nav-collapse_">Menu <span class="icon-bar"></span> </a>
            <div class="nav-collapse nav-collapse_  collapse">
                  <ul class="nav sf-menu">
                <li><a href="index.php">Home</a></li>
                <li class="active" class="sub-menu"><a href="books.php">Books</a>
                      <ul style="z-index:100;">
                    <li><a href="engineering.php">Engineering </a></li>
                    <li><a href="medical.php">Medical</a></li>
                    <li><a href="commerce.php">Commerce</a></li>
					<li><a href="arts.php">Arts</a></li>
                  </ul>
                    </li>
                
                <li><a href="contact.php">Contact</a></li>
				<?php
				if(ISSET($_SESSION['username']))
				{ ?>
				<li><a href="home.php">Account</a></li>
				<li><a href="logout.php">Logout</a></li>
				<?php } 
				else
				{
				?>
				<li><a href="login.php#tologin">Login</a></li>
				<?php } ?>
              </ul>
                </div>
          </div>
            </div>
      </div>
        </div>
  </div>
    </header>
<div class="bg-content"> 
<br/>      
  <!--============================== content =================================-->      
    <div class="container">
          <div class="row">
           <section id="isotope">
				<div class="row">
				
					<div class="span13">
				
<div id="options" class="clearfix">
      <ul id="filters" class="pagination option-set clearfix" data-option-key="filter">
        <b><li><a href="#filter" data-option-value="*" class="selected">show all</a></li>
        <li><a href="#filter" data-option-value=".Civil">Civil</a></li>
        <li><a href="#filter" data-option-value=".Mechanical">Mech</a></li>
		<li><a href="#filter" data-option-value=".Computers">Comps</a></li>
		<li><a href="#filter" data-option-value=".Prod">Tronix</a></li>
		<li><a href="#filter" data-option-value=".Chemical">Chemical</a></li>
		<li><a href="#filter" data-option-value=".IT or IS">IT/IS</a></li>
		<li><a href="#filter" data-option-value=".Trical">Electrical</a></li>
		<li><a href="#filter" data-option-value=".Tronix">Electronics</a></li>
		<li><a href="#filter" data-option-value=".EXTC">EXTC</a></li>
		<li><a href="#filter" data-option-value=".Biomed">Biomedical</a></li>
		<li><a href="#filter" data-option-value=".Instrumentation">Instrumentation</a></li>
		<li><a href="#filter" data-option-value=".Automobile">Automobile</a></li>
		<li><a href="#filter" data-option-value=".Bio-Technology">Bio-Tech</a></li>
		<li><a href="#filter" data-option-value=".Textile">Textile</a></li>
		<li><a href="#filter" data-option-value=".Marine">Marine</a></li></b>
		
      </ul>
	  
	  
  </div> <!-- #options -->
				
    <?php 
	include ("connection.php");
			$result = mysql_query("select * from books where category='eng';");
			$exist = mysql_num_rows($result);
			if($exist >= 1)
			{ ?>
			<script>
		$(document).ready(function() {
									$("#container").html('');
									                });
		</script>
<?php
					while($row = mysql_fetch_array($result))
					{
										$imagename="images/".$row['bookid'].".jpg";
	
		?>
		<script>
		$(document).ready(function() {
					
					
					$("#container").append('<div class="element transition" id="<?php echo $row['bookid']?>" data-category="transition"> <div class="thumbnail"> <div class="thumbnail"> <img src="<?php echo $imagename?>" alt="abc" width="250" height="127"> <div class="caption"> <h5> <?php echo "Name : ".$row['name']; echo "<br>Publication : ".$row['publication']; echo "<br>Author : ".$row['author']; echo "<br>Price :".$row['price'];?></h5><a href="bookview.php?bookid=<?php echo $row['bookid']?> " class="btn" target="_blank">Read More</a> </div> </div> </div> </div>');
					var ida = <?php echo $row['bookid']?>;
					var branch = "element transition <?php echo $row['branch']?>";
					var mydiv = document.getElementById(ida);
				    mydiv.setAttribute("class", branch);
				});
		</script>

						
							
						
					<?php 
				    } //end while
					?>
									               
			<?php
			}
			else
				{ ?>
						
					<section><div id="container_demo" ><div id="wrapper"><div id="login" class="animate form">No results found</div></div></div></section>
			<?php
			}
		?>
					<br />
					<br/>
					
			
				
				<script>

		    function getEventTarget(e) {
        e = e || window.event;
        return e.target || e.srcElement; 
    }

    var ul = document.getElementById('filters');
    ul.onclick = function(event) {
        
		onbranchclick();
    };
			</script>

		  <div id="container" class="clearfix span9">

		  
					</div>
					<article class="span3">
				<?php include("search.php")?>
				</article>
				
				<article class="span3">
				<?php //include("advertisements.php")?>
				</article>
				
				</div>
			</div>

	<div style="clear:both;"></div>
	

		</div>
	</div>
			</section>

        
      </div>
     </div>
  </div>

 </div>

<!--============================== footer =================================-->
<footer>
     <?php include "footer.php";?>
    </footer>
<script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>
    <script src="js/prettify.js"></script>
    <script src="js/bootstrap-transition.js"></script>
    <script src="js/bootstrap-alert.js"></script>
    <script src="js/bootstrap-modal.js"></script>
    <script src="js/bootstrap-dropdown.js"></script>
    <script src="js/bootstrap-scrollspy.js"></script>
    <script src="js/bootstrap-tab.js"></script>
    <script src="js/bootstrap-tooltip.js"></script>
    <script src="js/bootstrap-popover.js"></script>
    <script src="js/bootstrap-button.js"></script>
    <script src="js/bootstrap-collapse.js"></script>
    <script src="js/bootstrap-carousel.js"></script>
    <script src="js/bootstrap-typeahead.js"></script>
    <script src="js/bootstrap-affix.js"></script>
    <script src="js/application.js"></script>
    <script src="js/jquery.cookie.js"></script>
  	<script src="js/jquery.isotope.min.js"></script>
	
<script>
	function onbranchclick(){
	 
	  var $container = $('#container');

	  $container.isotope({
	    itemSelector : '.element'
	  });
	  
	  
	  var $optionSets = $('#options .option-set'),
	      $optionLinks = $optionSets.find('a');

	  $optionLinks.click(function(){
	    var $this = $(this);
	    // don't proceed if already selected
	    if ( $this.hasClass('selected') ) {
	      return false;
	    }
	    var $optionSet = $this.parents('.option-set');
	    $optionSet.find('.selected').removeClass('selected');
	    $this.addClass('selected');

	    // make option object dynamically, i.e. { filter: '.my-filter-class' }
	    var options = {},
	        key = $optionSet.attr('data-option-key'),
	        value = $this.attr('data-option-value');
	    // parse 'false' as false boolean
	    value = value === 'false' ? false : value;
	    options[ key ] = value;
	    if ( key === 'layoutMode' && typeof changeLayoutMode === 'function' ) {
	      // changes in layout modes need extra logic
	      changeLayoutMode( $this, options )
	    } else {
	      // otherwise, apply new options
	      $container.isotope( options );
	    }
	    
	    return false;
	  });

	  
	}
	</script>
</body>
</html>