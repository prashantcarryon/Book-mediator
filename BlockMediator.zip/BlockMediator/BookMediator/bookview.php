<?php session_start();$_SESSION["url"]=$_SERVER['REQUEST_URI']; if(ISSET($_SESSION['username'])) { ?>
<!DOCTYPE html>
<html lang="en">
	<head>
	<title>Book Details</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <link rel="shortcut icon" href="../favicon.ico"> 
        <link rel="stylesheet" type="text/css" href="css/demo.css" />
        <link rel="stylesheet" type="text/css" href="css/style3.css" />
		<link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
	<meta charset="utf-8">
	<link rel="icon" href="img/favicon.png" type="image/x-icon">
	<link rel="shortcut icon" href="img/favicon.png" type="image/x-icon" />
	<meta name="description" content="Your description">
	<meta name="keywords" content="Your keywords">
	<meta name="author" content="Your name">
	<link rel="stylesheet" href="css/bootstrap.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/responsive.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300' rel='stylesheet' type='text/css'>
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/superfish.js"></script>
	<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
	    
	<script type="text/javascript">if($(window).width()>1024){document.write("<"+"script src='js/jquery.preloader.js'></"+"script>");}	</script>
	<script>		
		 jQuery(window).load(function() {	
		 $x = $(window).width();		
	if($x > 1024)
	{			
	jQuery("#content .row").preloader();}	
	
	jQuery(".list-blog li:last-child").addClass("last"); 
	jQuery(".list li:last-child").addClass("last"); 

	
    jQuery('.spinner').animate({'opacity':0},1000,'easeOutCubic',function (){jQuery(this).css('display','none')});	
  		  }); 
					
	</script>

	<!--[if lt IE 8]>
  		<div style='text-align:center'><a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.com/img/upgrade.jpg"border="0"alt=""/></a></div>  
 	<![endif]-->
	<!--[if (gt IE 9)|!(IE)]><!-->
	<!--<![endif]-->
	<!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>    
    <link rel="stylesheet" href="css/ie.css" type="text/css" media="screen">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400' rel='stylesheet' type='text/css'>
  <![endif]-->
	</head>

	<body>
<div class="spinner"></div>
<!--============================== header =================================-->

      <header>
      <?php include "header.php";?>      
    </header>

<div class="bg-content"> 
<br/>      
  <!--============================== content =================================-->      
  <center>
  
             <div class="row">

  <div id="bookview" class="bookview">

   <article class="span10">
   <div class="element transition"  data-category="transition"> 
   <div class="thumbnail"> 
   <div class="thumbnail"> 
   <br><br>
  
   
   <?php 
		include ("connection.php");
		$bookid = $_GET['bookid'];
		$imagename="images/".$bookid.".jpg";
		$result = mysql_query("select * from books where bookid=$bookid;");
		$row = mysql_fetch_array($result);
		$emailid = mysql_query("select email from users,books where books.userid=users.userid and books.userid='".$row['userid']."';");
		$res = mysql_fetch_array($emailid);
        ?>
		
		 <img src="<?php echo $imagename?>" alt="abc"><br><br>
		 <div class="caption"> 
         <h5 align="left" style="margin-left:100px;"> 
		<table class="book_detail_table" style="border:3px solid #fff; margin-left:-20px;" cellpadding="10" cellspacing="10">
		            <col width="250">
            <col width="500">

					<tbody style="font-weight:bold; font-size:20px; padding: 10px 10px 10px 10px; ">
					
					<tr style="border:1px solid #fff; ">
						<td style="border:1px solid #fff; "><p style="margin-left:10px;"><br>Name of Book<br></p></td><td  style="border:1px solid #fff; color:#0088cc; left:10px;"><br><p style="margin-left:10px;">         <?php echo $row['name']; ?><br></p>
 </td>
					</tr>
					<tr style="border:1px solid #fff;">
						<td style="border:1px solid #fff;"><p style="margin-left:10px;"><br>Publication of Book<br></p></td><td style="border:1px solid #fff; color:#0088cc;" ><p style="margin-left:10px;"><br> <?php echo $row['publication']; ?> <br></p></td>
					</tr
					<tr style="border:1px solid #fff;">
						<td style="border:1px solid #fff; "><p style="margin-left:10px;"><br>Author of Book<br></p></td><td  style="border:1px solid #fff; color:#0088cc;"> <p style="margin-left:10px;"><br><?php echo $row['author']; ?><br></p> </td>
					</tr>
					
					<tr style="border:1px solid #fff;">
						<td style="border:1px solid #fff;"><p style="margin-left:10px;"><br>Stream<br></p> </td>
						<td style="border:1px solid #fff; color:#0088cc;"> <p style="margin-left:10px;"><br>
    						<?php echo $row['category']; ?><br></p>
							
						</td>
					</tr>
					<tr style="border:1px solid #fff;">
						<td style="border:1px solid #fff;"><p style="margin-left:10px;"><br>Branch <br></p></td>
						<td style="border:1px solid #fff; color:#0088cc;"> <p style="margin-left:10px;"><br>
							<?php echo $row['branch']; ?><br></p>
						</td>
					</tr>
					
					<tr style="border:1px solid #fff;">
						<td style="border:1px solid #fff;"><p style="margin-left:10px;"><br>Book used for <br></p></td>
						<td style="border:1px solid #fff; color:#0088cc;"><p style="margin-left:10px;"><br>
							<?php echo $row['usedfor']; ?> months<br></p>
						</td>
					</tr>
					<tr style="border:1px solid #fff;">
						<td style="border:1px solid #fff;"><p style="margin-left:10px;"><br>Book Quality<br></p></td>
						<td style="border:1px solid #fff; color:#0088cc;"><p style="margin-left:10px;"><br>
							<?php echo $row['quality']; ?> (From 1-5)<br></p>
						</td>
					</tr>
					<tr style="border:1px solid #fff;">
						<td style="border:1px solid #fff;"><p style="margin-left:10px;"><br>Resale Price <br></p></td>
						<td style="border:1px solid #fff; color:#0088cc;"><p style="margin-left:10px;"><br> Rs. <?php echo $row['price']; ?> <br></p></td>
					</tr>
					
					<tr style="border:1px solid #fff;">
						<td style="border:1px solid #fff;"><p style="margin-left:10px;"><br>Advertiser Email <br></p></td>
						
						  
						<td style="border:1px solid #fff; color:#0088cc;"><p style="margin-left:10px;"><br> <?php echo $res['email']; ?> <br></p></td>
					</tr>
					
					
				</tbody></table>
	
	
   </h5><br>
   <p>Note : If you want to buy this book, click on "Send Email" button below. An email will be sent to the advertiser.<br><br>
    <a href="sendmail.php?email=<?php echo $res['email']?>&bookid=<?php echo $bookid?>" class="btn">Send Email</a>
   </div>
   </div> 
   </div> 
   </div>
    			</article>
				<article class="span3">
				<?php include("advertisements.php")?>
				</article>
				</div>
	</div>
	</center>
	
 </div>

<!--============================== footer =================================-->
<footer>
     <?php include "footer.php";?>
    </footer>
<script type="text/javascript" src="js/bootstrap.js"></script>
<?php } 
else
header("location: loginview.php#tologin");
?>

</body>
</html>