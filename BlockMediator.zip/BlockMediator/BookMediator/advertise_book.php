<?php session_start(); if(ISSET($_SESSION['username'])) { ?>
<!DOCTYPE html>
<html lang="en">
	<head>
	<title>Advertise Book</title>
	<meta charset="utf-8">
	<link rel="icon" href="img/favicon.png" type="image/x-icon">
	<link rel="shortcut icon" href="img/favicon.png" type="image/x-icon" />
	<meta name="description" content="Your description">
	<meta name="keywords" content="Your keywords">
	<meta name="author" content="Your name">
	<link rel="stylesheet" href="css/bootstrap.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/responsive.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/tm_docs.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/touchTouch.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/kwicks-slider.css" type="text/css" media="screen">
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300' rel='stylesheet' type='text/css'>
	<script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/superfish.js"></script>
	<script type="text/javascript" src="js/jquery.flexslider-min.js"></script>
	<script type="text/javascript" src="js/jquery.kwicks-1.5.1.js"></script>
	<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>	  
	<script type="text/javascript" src="js/touchTouch.jquery.js"></script>
	<script type="text/javascript">if($(window).width()>1024){document.write("<"+"script src='js/jquery.preloader.js'></"+"script>");}	</script>

	<script>		
		 jQuery(window).load(function() {	
		 $x = $(window).width();		
	if($x > 1024)
	{			
	jQuery("#content .row").preloader();    }	
		 
     jQuery('.magnifier').touchTouch();			
    jQuery('.spinner').animate({'opacity':0},1000,'easeOutCubic',function (){jQuery(this).css('display','none')});	
  		  }); 
				
	</script>

	<!--[if lt IE 8]>
  		<div style='text-align:center'><a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.com/img/upgrade.jpg"border="0"alt=""/></a></div>  
 	<![endif]-->
	<!--[if (gt IE 9)|!(IE)]><!-->
	<!--<![endif]-->
	<!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <link rel="stylesheet" href="css/ie.css" type="text/css" media="screen">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400' rel='stylesheet' type='text/css'>
  <![endif]-->
	</head>

	<body>
    <div class="spinner"></div> 
<!--============================== header =================================-->
<header>
      <?php include "header.php";?>      
    </header>
<div class="bg-content">
      
      
      <!--============================== content =================================-->
      
      <div id="content" class="content-extra">
        
        
    <div class="container">
          <div class="row">
        <article class="span9">
              <h3>Advertise Book</h3>
                        <form method="POST" action="submit_ad.php" enctype="multipart/form-data" accept="image/gif,image/jpeg" onsubmit="return validation_check()">
				
              <table class="book_detail_table">
					<tbody><tr>
						<td align="left">Name of Book:</td><td align="left"> <input type="text" name="name" required="required" pattern="[a-zA-Z ]+" id="nameb" style="width:450px;"> </td>
					</tr>
					<tr>
						<td align="left">Publication of Book:</td><td align="left"> <input type="text" name="publication" required="required" id="publication" style="width:300px;"> </td>
					</tr>
					<tr>
						<td align="left">Author of Book:</td><td align="left"> <input type="text" name="author" required="required" pattern="[a-zA-Z ]+" id="author" style="width:300px;"> </td>
					</tr>
					
					<tr>
						<td align="left">Stream: </td>
						<td align="left"> 
    						<select name="stream" id="stream">
								<option value="eng">Engineering</option>
								<option value="medical">Medical</option>
								<option value="commerce">Commerce</option>
								<option value="pharmacy">Pharmacy</option>
								<option value="architecture">Architecture</option>
								<option value="science">Science</option>
								<option value="arts">Arts</option>
								<option value="law">Law</option>
								<option value="management">Management</option>
								<option value="IT or IS">IT</option>
							</select>
						</td>
					</tr>
					<tr>
						<td align="left">Branch: </td>
						<td align="left"> 
							<select name="branch" id="branch"> 
                                <option value="Mechanical">Mechanical</option>
                                <option value="Civil">Civil</option>
                                <option value="Chemical">Chemical</option>
                                <option value="Computers">Computers</option>
                                <option value="IT or IS">Information Technology (IT)/Information Science (IS)</option>
                                <option value="Trical">Electrical/EEE</option>
                                <option value="Tronix">Electronics/ECE</option>
                                <option value="EXTC">Electronics &amp; Telecommunication</option>
                                <option value="Prod">Production/Industrial Engg &amp; Mgmt</option>
                                <option value="Biomed">Biomedical/Medical Electronics</option>
                                <option value="Instrumentation">Instrumentation</option>
                                <option value="Automobile">Automobile</option>
                                <option value="Bio-Technology">Bio-Technology</option>
                                <option value="Textile">Textile</option>
                                <option value="Marine">Marine</option>
							</select>
						</td>
					</tr>
					
					<tr>
						<td align="left">Book used for: </td>
						<td align="left">
							<select name="used">
								<option value="1">1</option>
								<option value="2">2</option>
								<option value="3">3</option>
								<option value="4">4</option>
								<option value="5">5</option>
								<option value="6">6</option>
								<option value="7">7</option>
								<option value="more">more</option>
							</select> months
						</td>
					</tr>
					<tr>
						<td align="left">Book Quality</td>
						<td align="left">
							<input type="range" name="b_quality" min="1" max="5" required="required">
							<br><span id="msg_red">(Rate your book Quality between 1-5)</span>
						</td>
					</tr>
					<tr>
						<td align="left">Set Resale Price: </td>
						<td align="left"> <input type="text" name="resale_price" id="resale_price" required="required" pattern="[0-9]+"> </td>
					</tr>
					
					<tr>
						<td valign="top" align="left">Search Tags:</td><td align="left"> <input name="detail" id="detail" style="width:400px;height:30px;" placeholder="Give comma-separated tags  Eg: maths, m1, kumbhojkar">
						</td>						
					</tr>
					<tr>
						<td align="left"><br>Upload valid Book Image</td>
						<td align="left"><br>
							<input type="file" name="book_image" id="pic" required="required">
							(Please upload Only jpg images)
						</td>
					</tr>
					<tr>
					<td colspan="2" align="left"><br><br><br><center><input type="submit" style="width:150px;"></center></td>
					</tr>
					
				</tbody></table>
			</form>
            </article>
        <article class="span3">
              <?php include "advertisements.php";?>
            </article>
      </div>
        </div>
  </div>
    </div>

<!--============================== footer =================================-->
<footer>
      <?php include "footer.php";?>
    </footer>
<script type="text/javascript" src="js/bootstrap.js"></script>
<?php } 
else
header("location: login.php#tologin");
?>

</body>
</html>						