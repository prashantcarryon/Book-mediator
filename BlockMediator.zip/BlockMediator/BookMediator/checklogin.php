<?ob_start();?>
<?php
session_start();
include "connection.php" ;
$username = $_REQUEST['username'];
$password = $_REQUEST['password'];
$query = "select email, password from users where email = '$username' and password = '$password'";
$runquery = mysql_query($query);
$exist_or_not = mysql_num_rows($runquery);
if ($exist_or_not)
{
$_SESSION['email'] = $username;
$query1="SELECT userid, name from users WHERE email='$username' and password = '$password'";
	$b1=mysql_query($query1);
	$row1=mysql_fetch_assoc($b1);
	$userid=$row1['userid'];
	$username=$row1['name'];
	$_SESSION['userid']=$userid;
		$_SESSION['username']=$username;

header("location: home.php");

}
else
{
header("location: login.php#tologin");
}
?>
<?ob_flush();?>