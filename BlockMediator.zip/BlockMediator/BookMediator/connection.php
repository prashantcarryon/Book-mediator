<?php
$con=mysql_connect("localhost","root","") or die("Couldn't connect to server!");
$qr=mysql_select_db("bookschain",$con) or die("Couldn't select database!");
 
?>