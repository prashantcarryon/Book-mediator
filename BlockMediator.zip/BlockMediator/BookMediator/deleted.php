<?php session_start();$_SESSION["url"]=$_SERVER['REQUEST_URI']; if(ISSET($_SESSION['username'])) { ?>
<!DOCTYPE html>
<html lang="en">
	<head>
	<title>Ad deleted</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <link rel="shortcut icon" href="../favicon.ico"> 
        <link rel="stylesheet" type="text/css" href="css/demo.css" />
        <link rel="stylesheet" type="text/css" href="css/style3.css" />
		<link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
	<meta charset="utf-8">
	<link rel="icon" href="img/favicon.png" type="image/x-icon">
	<link rel="shortcut icon" href="img/favicon.png" type="image/x-icon" />
	<meta name="description" content="Your description">
	<meta name="keywords" content="Your keywords">
	<meta name="author" content="Your name">
	<link rel="stylesheet" href="css/bootstrap.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/responsive.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300' rel='stylesheet' type='text/css'>
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/superfish.js"></script>
	<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
	    
	<script type="text/javascript">if($(window).width()>1024){document.write("<"+"script src='js/jquery.preloader.js'></"+"script>");}	</script>
	<script>		
		 jQuery(window).load(function() {	
		 $x = $(window).width();		
	if($x > 1024)
	{			
	jQuery("#content .row").preloader();}	
	
	jQuery(".list-blog li:last-child").addClass("last"); 
	jQuery(".list li:last-child").addClass("last"); 

	
    jQuery('.spinner').animate({'opacity':0},1000,'easeOutCubic',function (){jQuery(this).css('display','none')});	
  		  }); 
					
	</script>

	<!--[if lt IE 8]>
  		<div style='text-align:center'><a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.com/img/upgrade.jpg"border="0"alt=""/></a></div>  
 	<![endif]-->
	<!--[if (gt IE 9)|!(IE)]><!-->
	<!--<![endif]-->
	<!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>    
    <link rel="stylesheet" href="css/ie.css" type="text/css" media="screen">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400' rel='stylesheet' type='text/css'>
  <![endif]-->
	</head>

	<body>
<div class="spinner"></div>
<!--============================== header =================================-->

      <header>
      <?php include "header.php";?>      
    </header>

<div class="bg-content"> 
<br/>      
  <!--============================== content =================================-->      
  <center>
  
             <div class="row">
			       

  <div id="bookview" class="bookview">

   <article class="span10">
   <div class="element transition"  data-category="transition"> 
   <br><br>
   <div id="wrapper">
                        <div id="login" class="animate form">
             
   
   <?php 
		include ("connection.php");
		$bookid = $_GET['bookid'];
		$imagename="images/".$bookid.".jpg";
		$result = mysql_query("delete from books where bookid=$bookid;");
		// See if it exists before attempting deletion on it
if (file_exists($imagename)) {
    unlink($imagename); // Delete now
} 

        ?>
		
		 
   <p>Your advertisement for book resale is deleted.<br><br>
    <a href="home.php" class="btn">Go back to home page</a>
   </div>
   </div>
    			</article>
				<article class="span3">
				<?php include("advertisements.php")?>
				</article>
				</div>
	</div>
	</center>
	
 </div>
</div>
</div>
<!--============================== footer =================================-->
<footer>
     <?php include "footer.php";?>
    </footer>
<script type="text/javascript" src="js/bootstrap.js"></script>
<?php } 
else
header("location: loginview.php#tologin");
?>

</body>
</html>