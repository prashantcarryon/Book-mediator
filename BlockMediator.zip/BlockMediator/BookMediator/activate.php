<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
	<head>
	<title>Registration</title>
	<meta charset="utf-8">
	<link rel="icon" href="img/favicon.png" type="image/x-icon">
	<link rel="shortcut icon" href="img/favicon.png" type="image/x-icon" />
	<meta name="description" content="Your description">
	<meta name="keywords" content="Your keywords">
	<meta name="author" content="Your name">
	<link rel="stylesheet" href="css/bootstrap.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/responsive.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/tm_docs.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/touchTouch.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/kwicks-slider.css" type="text/css" media="screen">
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300' rel='stylesheet' type='text/css'>
	<script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/superfish.js"></script>
	<script type="text/javascript" src="js/jquery.flexslider-min.js"></script>
	<script type="text/javascript" src="js/jquery.kwicks-1.5.1.js"></script>
	<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>	  
	<script type="text/javascript" src="js/touchTouch.jquery.js"></script>
	<script type="text/javascript">if($(window).width()>1024){document.write("<"+"script src='js/jquery.preloader.js'></"+"script>");}	</script>

	<script>		
		 jQuery(window).load(function() {	
		 $x = $(window).width();		
	if($x > 1024)
	{			
	jQuery("#content .row").preloader();    }	
		 
     jQuery('.magnifier').touchTouch();			
    jQuery('.spinner').animate({'opacity':0},1000,'easeOutCubic',function (){jQuery(this).css('display','none')});	
  		  }); 
				
	</script>

	<!--[if lt IE 8]>
  		<div style='text-align:center'><a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.com/img/upgrade.jpg"border="0"alt=""/></a></div>  
 	<![endif]-->
	<!--[if (gt IE 9)|!(IE)]><!-->
	<!--<![endif]-->
	<!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <link rel="stylesheet" href="css/ie.css" type="text/css" media="screen">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400' rel='stylesheet' type='text/css'>
  <![endif]-->
	</head>

	<body>


<script>
var x;
function checkForm(f)
{


    if (f==1) 
    {
	 alert("Username or email was already used");
	   }

	if (empty($_POST['email'])) {
	        alert("Please Enter your Email");
	    } else {
	 
	        if (preg_match("/^([a-zA-Z0-9])+([a-zA-Z0-9\._-])*@([a-zA-Z0-9_-])+([a-zA-Z0-9\._-]+)+$/",
	            $_POST['email'])) {
	            //regular expression for email validation
	            $Email = $_POST['email'];
	        } else {
	           alert("Your EMail Address is invalid"); 
	        }
	 
	    }
	    
	  

   

}
 
$(document).ready(function(){
$('#name').keyup(username_check);
$('#email').keyup(email_check);
});
     
function username_check()
{  
var username = $('#name').val();
if(username == "" || username.length < 4)
{
$('#name').css('border', '3px #CCC solid');
$('#tick').hide();
}
else{
 
jQuery.ajax({
   type: "POST",
   url: "checkusername1.php",
   data: 'username='+ username,
   cache: false,
   success: function(response){
 
if(response == 1){
    x=response;
    $('#asdf').val(response);
    $('#username').css('border', '3px #C33 solid');
    $('#tick').hide();
    $('#cross').fadeIn();
    }
else{
    x=response;
    $('#asdf').val(response);
    $('#name').css('border', '3px #090 solid');
    $('#cross').hide();
    $('#tick').fadeIn();
    }
 
}
});
}
}
 
function email_check()
{  
var email = $('#email').val();
if(email == "")
{
$('#email').css('border', '3px #CCC solid');
$('#tick2').hide();
}
else{
 
jQuery.ajax({
   type: "POST",
   url: "checkemail.php",
   data: 'email='+ email,
   cache: false,
   success: function(responsee){
 
if(responsee == 1){
    x=responsee;
    $('#email').css('border', '3px #C33 solid');   
    $('#tick2').hide();
    $('#cross2').fadeIn();
    }
else{
    x=responsee;
    $('#email').css('border', '3px #090 solid');
    $('#cross2').hide();
    $('#tick2').fadeIn();
    }
 
}
});
}
}

 
<style>
#alert
{
font-weight:bold;
color:red;
}
#username{
    padding:3px;
    font-size:18px;
    border:3px #CCC solid;
    margin:4px;
}
#tbox,
.tbox
{
    padding:3px;
    font-size:18px;
    border:3px #CCC solid;
    margin:4px;
}
#tick{display:none;}
#cross{display:none;}
#tick2{display:none;}
#cross2{display:none;}

</style>

</script>
    <div class="spinner"></div> 
<!--============================== header =================================-->
<header>
      <?php include "header.php";?>      
    </header>
<div class="bg-content">
      
      
      <!--============================== content =================================-->
      
      <div id="content" class="content-extra">
        
        
    <div class="container">
          <div class="row">
        <article class="span9">
              <h3>Registration</h3>
<form action="submit.php" method="post"  onSubmit="return checkForm(this);">
         <center>               
			<input type="hidden" name="resale_advertise" value="1">
				
              <table class="book_detail_table">
					<tbody><tr>
						<td>Name:</td><td align="left"> <input type="text" name="name" id="tbox" required="required" readonly style="width:300px;color:#FFFFFF;" value="<?php if(isset($_GET['name'])) echo $_GET['name'];?>"</td> </td>
					</tr>
					<tr>
						<td>Email:</td><td align="left"> <input type="email" name="email" id="email" class="tbox" readonly style="width:300px;color:#FFFFFF;" required="required" value="<?php if(isset($_GET['email'])) echo $_GET['email'];?>"> </td>
					</tr>
					<tr>
						<td>Password:</td><td align="left"> <input type="password" name="password" id="password" readonly style="width:300px;color:#FFFFFF;" required="required" value="<?php if(isset($_GET['password'])) echo $_GET['password'];?>"> </td>
					</tr>
					<tr>
						<td>Mobile No.:</td><td align="left"> <input type="text" name="mobileno" id="tbox" pattern="[0-9]{10}" style="width:300px;" required="required" value="<?php if(isset($_GET['mobileno'])) echo $_GET['mobileno'];?>"> </textarea></td>
					</tr>
					<tr>
						<td>City: </td>
						<td> 
    						<input type="text" name="city" id="city" list="cities" required="required" value="<?php if(isset($_GET['city'])) echo $_GET['city'];?>"/>
                                                   <datalist id="cities"> 
                                                    <option value="Italy"> 
                                                     <option value="Sweden"> 
                                                      <option value="Denmark">
                                                       <option value="Denmark">
                                                       <option value="Denmark1">
                                                      <option value="Denmark2">
   
                                                          </datalist>
						</td>
					</tr>
                                           <tr>
						<td>Area:</td><td align="left"> <input type="text" name="area" id="area" style="width:300px;" required="required" value="<?php if(isset($_GET['area'])) echo $_GET['area'];?>"> </textarea></td>
					</tr>
                                        <tr>
						<td>College:</td><td align="left"> 
                                                  <input type="text" name="college" id="college" style="width:300px;"  list="colleges" required="required" value="<?php if(isset($_GET['college'])) echo $_GET['college'];?>"> 
                                                    <datalist id="colleges"> 


<option value="Aakash Educational Society, Aakash College of Commerce	Andheri	Commerce"> 
 <option value="Abhay Shikshan Kendra?s  Rajarshri Shahu College of Arts, Commerce & Science	Sion	Arts">
<option value="Abhay Shikshan Kendra?s  Rajarshri Shahu College of Arts, Commerce & Science	Sion	Science">
<option value="Abhay Shikshan Kendra?s  Rajarshri Shahu College of Arts, Commerce & Science	Sion	Commerce">
<option value="Abhay Shikshan Kendra?s Rajeshri Shahu College of Law	Sion	Law">
<option value="Abhinav Shetkari Shikshan Mandal' Abhinav College of Arts, Science and Commerce	Thane	Arts">
<option value="Abhinav Shetkari Shikshan Mandal' Abhinav College of Arts, Science and Commerce	Thane	Science">
<option value="Abhinav Shetkari Shikshan Mandal' Abhinav College of Arts, Science and Commerce	Thane	Commerce">
<option value="Adarsh Shikshan Mandal?s Ideal College of Pharmacy and Research	Ambernath	Pharmacy">
<option value="Adarsh Vidyaprasarak Sanstha's College of Arts & Commerce	Ambernath	Arts">
<option value="Adarsh Vidyaprasarak Sanstha's College of Arts & Commerce	Ambernath	Commerce">
<option value="Adarsh Vikas Mandal, Karmaveer Bhaurao Patil College of Arts and Commerce	Ambernath	Arts">
<option value="Adarsh Vikas Mandal, Karmaveer Bhaurao Patil College of Arts and Commerce	Ambernath	Commerce">
<option value="Adivasi Pragati Mandal Sanchalit Com. Godavari Shamrao Parulekar College of Arts, Science and Commerce	Talasari	Arts">
<option value="Adivasi Pragati Mandal Sanchalit Com. Godavari Shamrao Parulekar College of Arts, Science and Commerce	Talasari	Science">
<option value="Adivasi Pragati Mandal Sanchalit Com. Godavari Shamrao Parulekar College of Arts, Science and Commerce	Talasari	Commerce">
<option value="Agnel Charitable Trust?s Fr. Conceicao Rodrigues Institute of Technology	Vashi	Computer">
<option value="Agnel Charitable Trust?s Fr. Conceicao Rodrigues Institute of Technology	Vashi	Electrical">
<option value="Agnel Charitable Trust?s Fr. Conceicao Rodrigues Institute of Technology	Vashi	Elec.& Tele.Comm">
<option value="Agnel Charitable Trust?s Fr. Conceicao Rodrigues Institute of Technology	Vashi	Mechanical">
<option value="Agnel Charitable Trust?s Fr. Conceicao Rodrigues Institute of Technology	Vashi	I.T.">
<option value="Aldel Education Trust?s St. John College of Engg.	Palghar	Civil">
<option value="Aldel Education Trust?s St. John College of Engg.	Palghar	Computer">
<option value="Aldel Education Trust?s St. John College of Engg.	Palghar	I.T.">
<option value="Aldel Education Trust?s St. John College of Engg.	Palghar	Elec.& Tele.Comm">
<option value="Aldel Education Trust?s St. John Institute of Pharmacy	Palghar	Pharmacy">
<option value="Anandibai Damodar Kale Shaikshanik Sanstha's College of Arts and Commerce	Borivali	Arts">
<option value="Anandibai Damodar Kale Shaikshanik Sanstha's College of Arts and Commerce	Borivali	Science">
<option value="Anandibai Damodar Kale Shaikshanik Sanstha's College of Arts and Commerce	Borivali	Commerce">
<option value="Anjuman-I-Islam Institute of Management Studies	Fort	Management Studies">
<option value="Anjuman-I-Islam�s School of Architecture	Fort	Architechture">
<option value="Anjuman-I-Islam?s Akbar Peerbhoy College of Commerce & Economics	Grant Road	Commerce">

<option value="">Anjuman-I-Islam?s Allana Institute of Management Studies & A.K. Hafizka Institute of Hotel Management & Catering Technology	Fort	
<option value="Anjuman-I-Islam?s College of Hotel & Tourism Management Studies & Research	Fort">	
<option value="Anjuman-I-Islam?s M.H. Saboo Siddik College of Engineering	Byculla	">
<option value="Anjuman-I-Islam's School of Pharmacy	Fort">
<option value="Anjuman-I-Islam's, School of Engineering & Technology	Fort">	

<option value="">Annasaheb Vartak College of Arts, Kedarnath Malhotra College of Commerce and E.S.Andrades College of Science	Vasai	
<option value="Apeejay Education Trust?s College of B.Sc. (Hospitality Studies)	Belapur">	
<option value="Atharva Educational Trust, Atharva Institute of Management Studies	Malad">	
<option value="Atharva Educational Trust?s College of Bachelor of Hospitality Studies	Malad">	
<option value="Atharva Educational Trust?s College of Engineering	Malad">	
<option value="Audyogik Shikshan Mandal Institute of Management & Computer Studies	Thane">	
<option value="B.N.Bandodkar College of Science	Thane">	
<option value="B.P. Marine Academy	Belapur">	
<option value="BAL Bharati`s Maghanmal J. Pancholia College of  Commerce	Kandivali">	
<option value="Bharat Education Society?s Sant Gadge Maharaj College of Commerce & Economics	Grant Road">	
<option value="Bharat Friends Association's Bharat College of Arts & Commerce	Badlapur">	
<option value="Bharati Vidapeeth`s Regional Office College of MCA	Belapur">	
<option value="Bharati Vidyapeeth`s Institute College of Bachelor of Hotel & Tourism Management	Belapur">	
<option value="Bharati Vidyapeeth?s College of Engineering	Kharghar">	
<option value="Bharati Vidyapeeth?s College of Pharmacy	Belapur">	
<option value="Bharati Vidyapeeth's College of Architechture	Kharghar">	
<option value="Bharatiya Gramin Punarrachana Sanstha?s Institute of Management Degree College	Wadala">	
<option value="Bharatiya Vidya Bhavan`s  M. M.College of Arts, N.M.Institute of Science and  Haji Rashid Jaffer College of Commerce	Andheri	">
<option value="Bharatiya Vidya Bhavan`s Hazarimal Somani  College of Arts and Science	Grant Road">	
<option value="Bharti Vidyapeeth?s Institute of Management Studies & Research	Belapur">	
<option value="Bhartiya Gramin Punarrachana Sanstha?s Arts, Commerce and Science	Wadala">	
<option value="Bhartiya Vidya Bhavan?s Sardar Patel Institute of Technology	Andheri">	
<option value="Bhartiya Vidya Bhavan?s Shriyans Prasad Jain Institute of Management of Research	Andheri">	
<option value="Bhavana Trust College of Commerce & B.Sc (Computer Science)	Kurla">	
<option value="Bhavik Vidya Prasark Mandal?s Jai Bhagwan College of  Management, Science & Technology	Kalwa">	
<option value="Bhiwandi Weaver`s Education Society`s Samadiya College of Arts & Commerce	Bhiwandi">	
<option value="Birla College of Arts, Science & Commerce	Kalyan">	
<option value="Bombay College of Pharmacy Kalina	Santacruz">	
<option value="Bombay Suburban Art and Craft Education Society	Bandra">	
<option value="Bunts Sangha Mumbai?s Anna Leela College of Commerce, & Economics and Shobha Jayaram Shetty College for BMS	Kurla">	
<option value="Bunts Sangha's S.M. Shetty College of Science, Commerce and Management Studies	Powai">	
<option value="Burhani College of Commerce & Arts	Mazgaon">
<option value="Centre for Rural Entrepreneurship Development And Research	Vile-Parle">	
<option value="Chembur Trombay Education Society`s N.G.Acharya and D.K.Marathe College of Arts, Science and Commerce	Chembur">	
<option value="Chetana?s Ramprasad Khandelwal Institute of Management and Research	Bandra">	
<option value="Chetana's Hazarimal Somani   College of Commerce and Smt.Kusumtai Chaudhari College of Arts	Bandra">	
<option value="Chhatrapati Shikshan Mandal?s College of  Arts & Commerce College	Bhiwandi">	
<option value="Chikitsak Samuhas `s Sir Sitaram and Lady Shantabai  Patkar College of Arts and Science and V.R.Varde College of Commerce and Economics	Goregaon	">
<option value="Children Welfare Centre Clara's Commerce College	Andheri">	
<option value="Children Werlfare Centre's College of Law	Malad">	
<option value="Chinchni Tarapur Education Society's Shri Purshottamdas Laldas Shroff College of Arts & Commerce	Chinchani">	
<option value="Church of Our Lady of The Sea,St. Joseph College of Arts and Commerce	Bhayandar">	
<option value="College of Home Science, New Marine Lines	Marine Lines">	
<option value="College of Social Work, New Marine Lines	Marine Lines">	
<option value="Cosmopolitans Vallia Chhaganlal Laljibhai College of Commerce and Valia Lilavantiben Chhaganlal College of Arts	Andheri	">
<option value="D. E. Society's Kirti M. Doongursee College of Arts, Science & Commerce	Dadar">	
<option value="D.S.P. Mandal's K.V.Pendharkar College of Arts, Science and Commerce	Dombivli">	
<option value="Daar-Ul-Rehmat Trust`s  A.E. Kalsekar Arts, Science  & Commerce Degree College	Mumbra">	
<option value="Datta Meghe College of Engineering	Airoli">	
<option value="Deccan Education Society?s Navinchandra Mehta Institute of Technology and Development	Dadar">	
<option value="Dnyan Bharati Society's Sau. Sitabai Ramkrishna Karandikar College of Arts and Commerce & Late Mehernosh Boman Burjor Irani ">

<option value="College of Arts	Dahanu">	
<option value="Dnyan Ganga Education Turst College Of  Arts,Commerce, B.M.S. & B.Sc.(IT)	Thane">	
<option value="Dnyan Prasarak Shikshan Sanstha Rajiv Gandhi Night College of Arts And Commerce	Vikhroli">	
<option value="Dnyan Prasarak Shikshan Sanstha`s Sandesh College of Commerce	Vikhroli">	
<option value="Dnyan Prasarak Shikshan Sanstha?s Indira Gandhi College of Arts & Commerce	Vikhroli">	
<option value="Dnyan Vikas Sanstha?s College of Commerce	Vikhroli">	
<option value="Dnyansadhana College of Arts, Science and Commerce	Thane">	
<option value="Dr. Ambedkar College of Law	Wadala">	
<option value="Dyandeep Mandal`s St. Joseph Arts & Commerce College	Virar">	
<option value="Education Board Mulund?s Jai Bharat     College of Commerce (Night)	Mulund	">
<option value="Educational Uplift Society for Women,College of Arts, Science & Commerce	Kalyan	">
<option value="Elphinstone College	Fort	">
<option value="Esplanade Education Society?s Niranjana Majithia College of Commerce	Kandivali	">
<option value="Excelsior Education Society's K. B. College of Arts, Commerce and S.C.College of Science for Women	Thane">
<option value="Excelsior Education Society's K. C. College of Engineering	Thane">	
<option value="Fr. Conceicao Rodrigues Institue of Engineering	Vashi">
<option value="Fr. Conceicao Rodrigues College of Engineering	Bandra">	
<option value="Gayatri Shikshan Prasarak Mandals' College of Science	Bhopar	">
<option value="Gokhale Education Society's Dr.T.K.Tope Arts and Commerce Night College	Parel">	
<option value="Gokhale Education Society's N.B.Mehta (Valvada) Science College	Bordi">	
<option value="Gokhale Education Society's Shri Bhausaheb Vartak Arts, Science and Commerce College	Borivali">	
<option value="Gopaldas Jhamatmal Advani Law College	Bandra">	
<option value="Government Law College Churchgate	Churchgate">	
<option value="Government of India Ministry of Shipping Marine Engineering & Research Institute	Sewree">	
<option value="Government of Maharashtra Ismail Yusuf College	Jogeshwari">	
<option value="Government of Maharashtra Sydenham College of Commerce & Economics	Churchgate">	
<option value="Gramin Shikshan Sanstha`s College of Arts, Science and Commerce	Thane">	
<option value="Guru Nanak Khalsa College of Arts, Science & Commerce	Matunga">	
<option value="Gurukul Educational Institution`s Gurukul College of Commerce	Ghatkopar">	
<option value="H.R.College of Commerce & Economics	Churchgate">	
<option value="Habib Educational & Welfare Society�s, M.S. College of Law	Mumbra">	
<option value="Habib Educational & Welfare Society?s Arts, Commerce, Science and B.M.S.	Mumbra">	
<option value="Habib Esmail Education Trust?s, Habib College of Commerce	Dongri">	
<option value="Haji Jamaluddin Thim Trust College of BHTM, B.M.S. and B.Sc. (Computer Science)	Thane">	
<option value="Haji Jamaluddin Thim Trust, Theem College of Engineering	Boisar">	
<option value="Haji Karim Mohammed Suleman Charitble Trust?s College of Arts & Commerce for Women	Masjid Bandar">	
<option value="Hind Seva Parishad's Public Night Degree College of Arts and Commerce	Santacruz">	
<option value="Hindi Vidya Prachar Samiti`s Ramniranjan Jhunjhunwala College	Ghatkopar">	
<option value="Hyderabad (Sindh) National Collegiate Board?s College of Law	Churchgate">	
<option value="Hyderabad (Sindh) National Collegiate Board?s College of Pharmacy	Churchgate">	
<option value="Hyderabad (Sindh) National Collegiate Board?s College of Management	Churchgate">	
<option value="I.C.L.'s Motilal Jhunjhunwala Arts, Science and Commerce College	Vashi">	
<option value="Indian Education Society?s Management & Research Centre	Bandra">	
<option value="Indian Education Society's College of Architechture	Bandra">	
<option value="Innovative Engineer?s and Teacher?s Education Society, Leelavati Awhad Institute of Technology Management Studies & Research	Badlapur">	
<option value="Institute of Aviation and Aviation Safety Andheri (West)	Andheri">	
<option value="ITM Trust?s Institute of Hotel Management, Kharghar	Kharghar">	
<option value="Jai Hind  College, Basantsing Institute of Science and J.T.Lalvani College of Commerce	Churchgate">	
<option value="Jan Seva Sangh's, Shriram College of Commerce	Bhandup	">
<option value="Jan Utkarsha Prabodhini, Arts, Science & Commerce College Kalamdevi	Dahanu">	
<option value="Janardan Bhagat Shikshan Prasarak Sanstha's Changu Kana Thakur Arts, Commerce and Science College	Panvel">
<option value="Janseva Shikshan Mandal?s Jayandra Pawar Arts, Commerce & Science College	Murbad">	
<option value="Jawahar Education Society?s A.C.Patil College of Engineering	Kharghar">	
<option value="Jawahar Education Society?s Annasaheb Chudaman Patil College of Engineering	Kharghar">	
<option value="Jawaharlal Nehru Institute of Education Yashwantrao Chavan College of Arts, Commerce & Science 	Kopar Khairane">	
<option value="Jay Shri. Siddhivinayak Foundation�s B.R. Harne College of Engineering & Technology	Vangani">	
<option value="Jeevan Joyt Educational Trust`s Reena Mehta Arts & Commerce	Bhayandar">	
<option value="Jeevandeep Shaishnik Sanstha?s Poi?s College of Arts, Commerce & Science	Khardi">	
<option value="Jeevandip Shikshanik Sanstha?s Arts, Commerce and Science	Goveli">	
<option value="Jitendra Chauhan College of Law	Vile-Parle">	

<option value="Jnan Vikas Mandal's, Mohanlal Raichand Mehta College of Commerce, Diwali Maa College of Science, Amritlal Raichand 
                   Mehta College of Arts, Dr. R.T. Doshi College of Computer Science	Airoli">	
<option value="Jogeshwari  Education Society?s college of Commerce, Science and Information Technology	Jogeshwari">	
<option value="K. J. Somaiya Institute of Engineering and Information Technology	Sion">	
<option value="K.J. Somaiya College of  Science & Commerce, Vidyavihar	Vidyavihar">	
<option value="K.J. Somaiya College of Arts & Commerce	Vidyavihar">	
<option value="K.J. Somaiya College of Engineering Vidyanagar Campus, Vidyavihar	Vidyavihar">	
<option value="K.M.Agrawal College of Arts, Commerce and Science	Kalyan">	
<option value="K.P.B. Hinduja College of Commerce	Charni Road">
<option value="Kaiser Education Society, Kaiser College of Commerce	Bandra">	
<option value="Kalyan Wholesale Merchants Education Society`s Laxmen Devram Sonavane College of Arts & Commerce	Kalyan">	
<option value="Kamla  Raheja Vidyanidhi Institute of Architecture and Environmental Studies	Juhu">	
<option value="Kamladevi Educational Trust?s, Kamladevi College of Arts and Commerce	Malad">	
<option value="KAPOL Vidyanidhi Trust?s Kopal Vidyanidhi College of Hotel Management	Kandivali">	
<option value="Karaleeya Samajam Dombivli's Model College	Dombivli">	
<option value="Karnala Sports Academy?s KSA?S Barns college of Arts, Science & Commerce	Panvel">	
<option value="Karnataka Sangha?s Manjunatha College of  Commerce	Thakurli">	
<option value="Khar Education Society?s College of Commerce and B.M.S.	Khar Road">	
<option value="Kishinchand Chellaram College	Churchgate">	
<option value="Konkan Gyanpeeth College of Engineering	Karjat">	
<option value="Koti Vidya Charitable Trust?s Alamini Ratnamala Institute of Engineering & Technology	Shahapur">	
<option value="Lala Lajpat Rai Charitable Foundation?s College of Law	Mahalaxmi">	
<option value="Lala Lajpatrai College of Commerce And Economics	Mahalaxmi">	
<option value="Lala Lajpatrai College of Management Studies	Mahalaxmi">	
<option value="Late Bhausaheb Hiray S. S. Trust's Institute of Computer Application	Bandra">	
<option value="Late Bhausaheb Hiray Smarnika Samiti Trust's College of Architecture	Bandra">	
<option value="Late Shri Vishnu Waman Thakur Charitable Trust	Virar">	
<option value="Late Shri Vishnu Waman Thakur Charitable Trust?s Bhaskar Waman Thakur College of Science, Yashvant Keshav Patil College of Commerce, Vidya Dayanand Patil College of Arts	Virar">	
<option value="Late Shri. Vishnu Waman Thakur Charitable Trust, VIVA Institute of Technology	Virar">	
<option value="Late Smt. Hanjabai Gahlot Charitable Trust?s , College of Pharmacy	Nerul">	
<option value="Laxmi Education Society`s Chinai College of Commerce & Economics	Andheri">	
<option value="Laxmi Education Society`s Seth Laherchand Uttamchand Jhaveri College of Arts, Sir Mathurdas Vissonji College  of Science and Commerce	Andheri	">
<option value="Let. Smt. Hanjabai Gahlot Charitable Trusts? College of Management Studies & Research	Kopar Khairane">	
<option value="Lokmanya Nagar Shikshan Mandal`s R.J.Thakur College of  Arts & Commerce	Thane">	
<option value="Lokmanya Tilak Janakalyan Shikshan Santha�s Lokmanya Tilak Institute of Architecture and Design Studies Vashi">	
<option value="Lokmanya Tilak Jankalayn Shikshan Sanstha?s Lokmanya Tilak College of Engineering	Vashi">	
<option value="Maharashtra College of Arts, Science and Commerce	Byculla">	
<option value="Maharashtra Education Society?s H.K Institute of Management Studies and Research	Jogeshwari">	
<option value="Maharashtra Education Society?s H.K. College of Pharmacy	Jogeshwari">	
<option value="Maharshi Dayanand College of Arts, Science & Commerce	Parel">	
<option value="Mahatma Education Society?s Night College of Arts & Commerce	Chembur">	
<option value="Mahatma Education Society?s Pillai Institute of Information Technology, Engineering Media Studies & Research, Composite College Complex	Panvel">	
<option value="Mahatma Education Society?s Pillai Institute of Management Studies and Research	Panvel">	
<option value="Mahatma Education Society?s Vidyadhiraja College of Physical Education & Research	Panvel">	
<option value="Mahatma Education Society's Pillai College of Arts, Commerce & Science	Panvel">	
<option value="Mahatma Education Society's Pillai HOCL College of Engg. & Tech.	Panvel">	
<option value="Mahatma Gandhi Mission`s College of B.M.M Kamothe	Panvel">	
<option value="Mahatma Gandhi Mission`s College of Science	Panvel">	
<option value="Mahatma Gandhi Mission`s Law College	Panvel">	
<option value="Mahatma Gandhi Mission?s College of Engineering and Technology	Panvel">	
<option value="Mahatma Gandhi Mission?s Institute of Management	Panvel">	
<option value="Mahatma Phule Arts, Science and Commerce College	Panvel">	
<option value="Mahatma Phule Education Society?s College of Arts, Commerce 	Parel">	
<option value="Mahatma Phule Education Society's College of Arts & Commerce (Night)	Parel">	
<option value="Mahatma Phule Shikshan Sanstha`s College of Arts, Science & Commerce	Dharavi">	
<option value="Mahavir Education Trust?s Shah and Anchor Kutchi Engineering College	Chembur">	
<option value="Mahendra Pratap Sharada Prasad Singh College of  Arts, Science and Commerce	Bandra">	
<option value="Maitreya Bahuudheshiya Sevabhavi Sanstha, G.K.S. College of Arts, Commerce and Science 	Kalyan">	
<option value="Manisha Education Trust`s Smt. Janakibai Rama  Salvi College of Arts, Commerce & Science	Kalwa">	
<option value="Manjara  Charitable Trust�s Smt. Sushiladevi Deshmukh College of Arts, Science and Commerce	Airoli">
<option value="Manjara Charitable Trust?s Rajiv Gandhi Institute of Technology	Andheri	">
<option value="Manjra Charitable Trust?s College of Law	Airoli	Law">
<option value="Maratha Mandir Babasaheb Gawade Business School	Mumbai Central"> 	
<option value="Maratha Mandir?s Babasaheb Gawde Institute of Management Studies	Mumbai Central ">	
<option value="Master Education Society College of  Arts, Science and Commerce	Nalasopara">	
<option value="Matsyodari Shikshan Sanstha?s College of Commerce 	Vashi">	
<option value="Modern Education Society`s D.G. Ruparel College of Arts, Science and Commerce	Matunga">	
<option value="Mohindar Singh Kabal Singh College of Arts  & Commerce	Kalyan">	
<option value="Mulund Gymkhana?s College of Physical Education	Mulund">	
<option value="Mumbai Education Trust Institute of Computer Science	Bandra">	
<option value="Mumbai Educational Trust Institute of Phamacy	Bandra">	
<option value="Mumbai Educational Trust?s Institute Management Studies	Bandra">	
<option value="Mumbra Shikshan Prasarak G.R. Patil Science & Commerce College	Dombivli">	
<option value="Mumbra Shikshan Prasarak Mandal?s G. R.Patil College of Arts, Science & Commerce	Mumbra">
<option value="Nagarik Shikshan Santha?s College of Commerce	Tardeo">	
<option value="Nagindas Khandwala College of Commerce, Arts & Management Studies and Shantaben Nagindas Khandwala College of Science	Malad">
<option value="Nalanda Educational Foundation?s Dr. Babasaheb Ambedkar College of Arts, Science & Commerce	Chembur	">
<option value="Nalanda Nritya Kala Mahavidyalaya	Juhu">	
<option value="Namita Edu. & Welfair Society, Siddharth College of B.M.M., B.M.S. and B.Com	Badlapur">	
<option value="National Centre for Rural Development College Sterling Institute of Technology & Management of Master of Computer Application Course	Nerul">	
<option value="National Centre for Rural Development`s Sterling College of Arts, Science, & Commerce	Nerul">	
<option value="National Centre for Rural Development?s Sterling Institute of Management Studies	Nerul">	
<option value="National Centre for Rural Development?s Sterling Institute of Pharmacy	Nerul">	
<option value="National Education Soceity Ratnam College of Arts, Science and Commerce	Bhandup">	
<option value="Nava Balodyan Trust`s Kohinoor College of Hotel & Tourism Management Studies	Dadar">	
<option value="Navi Mumbai Mahila?s Utkarsha Mandal?s New Bombay City College	Vashi">	
<option value="New Law College Matunga	Matunga	Law">
<option value="Niranjanlal Dalmia Institute of Management Studies and Research	Mira Road">	
<option value="Nirmal Education Society College of Commerce	Ghatkopar">
<option value="Nirmal Education Society College of Commerce	Kandivali">	
<option value="Nirmala Memorial Foundation Degree College of Commerce and Science	Kandivali">	
<option value="Om Vidyalankar Shikshan Sanstha's Asmita College of Law	Vikhroli">	
<option value="Om Vidyalankar Shikshan Sanstha's Asmita College of Arts & Commerce for Women	Vikhroli">	
<option value="Oriental Education Society?s College of Arts, Commerce & Science	Sanpada">
<option value="Oriental Education Society?s College of Pharmacy	Sanpada">	
<option value="Oswal Shikshan & Rahat Sangh Sanchalit Shree Halari Visa Oswal College of Commerce	Bhiwandi">	
<option value="Our Lady of Grace Trust's St.Gonsalo Garcia College of Arts and Commerce	Vasai">	
<option value="P.D.Karkhanis College of Arts and Commerce College	Ambernath">	
<option value="Pad. Dr. D.Y.Patil College of Architecture	Nerul	Architechture">
<option value="Padmabhushan Vasantdada Patil Pratisthan?s College of Engineering	Sion">	
<option value="Padmashri Annasaheb Jadhav Bharatiya Samaj Unnati Mandal`s Bhiwandi Nizampur Nagarpalika Arts, Science & Commerce College	Bhiwandi	">
<option value="Parle Tilak Vidyalaya Association`s M.L.Dahanukar College of Commerce	Vile-Parle">	
<option value="Parle Tilak Vidyalaya Association`s Mulund College of Commerce	Vile-Parle">	
<option value="Parle Tilak Vidyalaya Association's Sathaye College	Vile-Parle">	
<option value="Parshvanath Charitable Trust Veer Mata Hiraben P. Shah College of Pharmacy	Thane">	
<option value="Parshvanath Charitable Trust?s Parshvanath College of Engineering	Thane">	
<option value="Patuck Polytechnic Trust, Patuck Gala College of Commerce	Santacruz">	
<option value="People Education Society�s Law College	Wadala">	
<option value="People's Education Society's Dr.Ambedkar College of Commerce & Economics	Wadala">	
<option value="People's Education Society's Siddharth College of  Arts, Science & Commerce	Fort">	
<option value="People's Education Society's Siddharth College of Commerce and Economics	Fort">	
<option value="Pradnya Karuna Bahudeshiya Shiksan Sanstha's Samayak Sanklpa College of Architechture	Kalyan">	
<option value="Pradnya Karuna Bahuodeshiya Shikshan Sanstha?s Arts, Commerce and Science	Kalyan">	
<option value="Pragat Samajik Shikshan Society?s Dr. Babasaheb Ambedkar Science and Adcovate Gurunath Kulkarni Commerce Mahavidyalaya	Vasai">
<option value="Prahladrai Dalmia Lions College of Commerce and Economics	Malad">	
<option value="Principal K.M. Kundanani College of Pharmacy	Cuffe Parade">	
<option value="Pune Vidyarthi Griha?s College of Science & Technology	Ghatkopar">	
<option value="R. A Podar College of Commerce & Economics	Matunga">	
<option value="R.K. Vidya Prasarak Mandal?s College of Physical Education	Kalyan">	
<option value="Rachana Sansad's Academy of Architechture	Worli">	
<option value="Rachana Sansad's College of Applied Arts and Craft	Worli">	
<option value="Rahul Shikshan Prasarak Mandal?s Satyagraha Mahavidyalaya	Kharghar">	
<option value="Rai`s Education Society`s S.K. Rai Degree College of Arts, Commerce & Management Studies	Chembur">	
<option value="Rajasthani Sammelan`s Ganshyamdas Saraf Girl's College of Arts & Commerce	Malad">	
<option value="Rajasthani Seva Sangha?s Smt. Parmeshwaridevi Durgadutt Tibrewala Lions Juhu College of Arts and Commerce Andheri">	
<option value="Rajiv Gandhi College of Arts Commerce & Science	Vashi">	
<option value="Ramanand Arya's D.A.V.College of Commerce,  Arts and Science	Bhandup	">
<option value="Ramji Assar Vidyala Committee?s College of Commerce	Ghatkopar">	
<option value="Ramrao Adik Education Society`s Padmashree Dr.D.Y.Patil Law College	Nerul">	
<option value="Ramrao Adik Institute of Technology	Nerul">	
<option value="Rashtriya Mill Mazdoor Sangh?s G.D. Ambedkar Pratishthan?s College of Management & Technology	Parel">	
<option value="Rashtriya Shikshan Sanstha's Swami Vivekanand (Night) College of Arts & Commerce	Dombivli">	
<option value="Rayat Shikshan Sanstha's Arts, Science and Commerce College	Mokhada	">
<option value="Rayat Shikshan Sanstha's Karmaveer Bhaurao Patil College      	Vashi">	
<option value="Rishi Dayaram National College of Arts and Commerce and Wassiamul Assomul Science College	Bandra">	
<option value="Ritambara Vishwa Vidyapeeth's Malini Kishor Sanghvi College of Commerce and Economics	Juhu">	
<option value="Rizvi Education Society Rizvi College of Law	Bandra">	
<option value="Rizvi Education Society?s Rizvi College, of Engineering	Bandra">	
<option value="Rizvi Education Society's College of Architechture	Bandra">	
<option value="Rizvi Education Society's College of Arts, Science and Commerce	Bandra">	
<option value="Rizvi Institute of Management Studies	Bandra">	
<option value="Royal Higher Education Society's College of Arts, Science and Commerce	Mira Road">	
<option value="S.I.E.S. College of Management Studies	Nerul">	
<option value="S.I.W.S's College of Commerce and Economics, and Smt.Thirumalai College of Science	Wadala">	
<option value="S.K.Somaiya Vidyavihar's College of Arts Science & Commerce	Vidyavihar">	
<option value="S.P.M. Mumbai?s Academy of Aviation	Kalyan">
<option value="Sadhana Education Society's L.S.Raheja College of Arts and Commerce	Santacruz">	
<option value="Sadhubella Education Society's J.Watumull Sadhubella Girls College,	Ulhasnagar">	
<option value="Sahayog College of Management Studies	Ambernath">	
<option value="Sahyadri Shaikshan Seva Mandal?s College of Arts and Commerce	Vasai">	
<option value="Sai Shiv Education Trust�s, Arun Muchhala International College of Hotel Management	Thane">	
<option value="Saket Gyanpeeth College of Arts & Commerce	Kalyan">	
<option value="Samaj Hitakarni Sanstha,  Utkarsha College of Arts & Commerce	Shahapur">	
<option value="Sanjivan Gramin Vaidyakiya & Samajik Sahayata Pratishthan College of Arts 	Vikramgad">	
<option value="Sanskar Sarjan Education Society?s Dhirajlal Talakchand Sankalchand Shah College of Commerce	Malad">	
<option value="Sanskardham Kelvani Mandal's Jashbhai Maganbhai Patel College of Commerce	Goregaon">	
<option value="Saraswati Education Society?s Yadavrao Tasgaonkar College of Engineeting & Management	Karjat">	
<option value="Saraswati Vidya Bhavan?s College of Pharmacy	Dombivli">	
<option value="Sardar Patel College of Engineering	Vile-Parle">	
<option value="Sarvadnya Education and Research Society?s College of Commerce & Science	Vashi">	
<option value="Seth Hirachand Mutha Shaikshanik Trust, College of Arts, Commerce & Science	Kalyan">	
<option value="Seva Sadan Trust, Seva Sadan College of Arts, Science & Commerce	Ulhasnagar">	
<option value="Seva Sadan`s R.K.Talreja College of Arts, Science and Commerce	Ulhasnagar">	
<option value="Shaheed Dunichand Tejandas Kalani Memorial Trust, College of Arts, Commerce & Science	Ulhasnagar">	
<option value="Shahu Shikshan Sanstha Nalanda College of Law	Borivali">	
<option value="Shahu Shikshan Sanstha, Devjibhai Hariya Law College	Kalyan">	
<option value="Shahu Shikshan Sanstha, Pandharpur Sanstha?s, Arts, Commerce and Science,	shahad	">
<option value="Shahu Shikshan Sanstha's College of Arts, Science & Commerce	Borivali">	
<option value="Shailendra Education Society's College of Arts, Commerce and Science	Dahisar	">
<option value="Shanmukhananda Fine Arts & Sangeetha Sabha	Sion	Fine Arts (Music)">
<option value="Sheth T.J.Education Society's Sheth Nanjibhai Khimjibhai Thakkar Thanawala College of Commerce and Sheth Jayantilal Tribhovandas Thanawala College of Arts and Science	Thane	">
<option value="Shetkari Shikshan Sanstha College of  BMS	Vashi">	
<option value="Shikshak Sanchalit Shikashan Sanstha's Arts and Commerce College	Wadala">	
<option value="Shikshan Prasarak Mandal?s N.R. Bhagat Jr. & Sr. College of Arts, Science and Commerce	Nerul">	

<option value="Shivai Prabhodhini Sanstha, Shri Ankushrao Tope Vidyan Mahavidlaya	Wadala">	
<option value="Shivajirao S. Jondhale College of Engineering	Dombivli">	
<option value="Shramik Shikshan Mandal?s F.G. Naik College of Arts, Commerce & Science	Kopar Khairane	">
<option value="Shree Ghatkopar Sarvajanik Jivdaya Khatu, Aruna Manharlal Shah Institute of Management & Research	Ghatkopar">	
<option value="Shree Narayan Mandir Samiti, Shree Narayan Guru Commerce College	Chembur">	
<option value="Shree Rahul Education Society, Mother Mary?s College	Bhayandar">	
<option value="Shree Shankar Naraya Education Trust?s Rohidas Patil Institute of Management Studies	Bhayandar">	

<option value="Shri Chhatrapati Shivaji Educational Society?s Late Sau S.R. Abhang ">
<option value="Memorial College of Arts and Commerce	Ulhasnagar	">
<option value="Shri Dombivli Mitra Mandal?s Matushri Kashiben Motilal Patel Sr. College of Science & Commerce	Thakurli">	
<option value="Shri Laxmandas Pitambardas  Rawal Education Trust?s Shri. L.P. Rawal College of Media Studies	Mira Road	">
<option value="Shri Madhavji Lall Welfare& Educational Trust?s Lord?s College of Law	Malad	">
<option value="Shri Narsee Monjee College of  Commerce & Economics	Vile-Parle	">
<option value="Shri Sadguru Vamanbaba Maharaj Shikshan Prasarak Mandal?s Eknath B. Madhavi Senior College of Arts, Commerce and Science	Dombivli	">
<option value="Shri Shankar Narayan Education Society's College of Arts, Commerce	Bhayandar">	
<option value="Shri Sudhir Madhavji Lall Welfare & Educational Trust?s   Lord?s Universal College of Commerce and Science & B.M.S.	Malad	">
<option value="Shri Vile Parle Kelavani Mandal`s Usha Pravin Gandhi College of Arts, Science & Commerce	Vile-Parle	">
<option value="Shri Vile Parle Kelavani Mandal?s Dwarkadas J. Sanghvi College of Engineering	Vile-Parle	">
<option value="Shri Vile Parle Kelavani Mandal?s Narsee Monjee Institute of Management Studies	Vile-Parle	">
<option value="Shri Vile Parle Kelvani Mandal`s Mithibai College of Arts, Chauhan Institute of Science and Amrutben Jivanlal College of Commerce and Economics	">
<option value="Shri Yashwantrao Chavan Shikshan Prasarak Mandal?s Sinhagad Institute of Business Management	Chadivali">	
<option value="Shri Yashwantrao Chavan Shikshan Prasarak Mandal?s Sinhgad College of Commerce	Chadivali	">
<option value="Shri. Hari Educational Trust?s College of Commerce	Borivali	">
<option value="Shri. N.B. Mehta Education Charity  Trust?s College of Commerce (Night)	Kandivali	">
<option value="Shri. N.B. Mehta Education Charity Trust?s Prakash Degree College of Commerce & Science	Kandivali	">
<option value="Shri. Vile Parle Kelvani Manda?s Dr. Bhanuben Nanavati College of Pharmacy	Vile-Parle	">
<option value="Shubhamkaroti Charitable & Education Trust?s Vasai College of Science & Technology	Vasai	
">


<option value="Shurparaka Educational and Medical Trust?sMoinuddin Burhan Harris ">

<option value="College of Arts & A.E. Kalsekar College of Commerce & Management	Nalasopara	">
<option value="Siddharth College of Law	Fort">
<option value="Siddhi Education Trust Bhanwabai Arjundas Talreja College  of Arts, Commerce & Science	Ambernath">	
<option value="Sindhu Bharati Trust?s Shri �Sindh Thakurnath� (S.S.T) College of Arts & Commerce	Ulhasnagar	">
<option value="Sindhu Education Society's, Swami Hansmuni Maharaj Degree College of Commerce	Ulhasnagar	">
<option value="Sir. J. J. College of Architecture	Fort">	
<option value="Sir. J.J. School of Applied Art	Fort">	
<option value="Sir. J.J. School of Art	Fort">	
<option value="Smt. Durga Devi Sharma Charitable Trust?s, Chandrabhan Sharma College of Arts, Commerce & Science	Powai	">
<option value="Smt. Fatimabai M. S. Educational Trust's Arts & Commerce (Night College)	Mumbra	">
<option value="Smt. Gulbanu A. Lalani Educational Trust?s College of Commerce for Women	Dahisar	">
<option value="Smt. Indira Gandhi Engineering College	Kopar Khairane	">
<option value="Smt.Chandibai Himathmal Mansukhani College	Ulhasnagar	">
<option value="Smt.Kamladevi Gauridatta  Mittal College of  Arts and Commerce	Malad">	
<option value="Smt.Mithibai Motiram Kundnani College of Commerce and Economics	Bandra	">
<option value="Society of the Congregation of Franciscan Brothers College of MMS	Borivali">	
<option value="Sonopant Dandekar Arts College, V.S.Apte Commerce and M.H.Mehta Science College	Palghar	">
<option value="Sonubhau Baswant College of Arts & Commerce	Shahapur	">
<option value="Sophia College for Women	Mahalaxmi	">
<option value="South Indian Children's Education Society's, Arts, Science & Commerce College	Ambernath	">
<option value="South Indian Education Scociety`s College of Engineering	Sion	">
<option value="South Indian Education Society's College of  Arts, Science and Commerce	Nerul">	
<option value="Sree Naryana Guru College of Commerce	Chembur	">
<option value="St. Francis Institute of Technology	Borivali	">
<option value="St. Wilfred College of Law	Panvel	">
<option value="St. Wilfred Education Society�s St. Wilfred�s Institute of  Architecture	Panvel	">
<option value="St. Xavier's College	Fort">	
<option value="St.Andrew`s College of Arts, Science & Commerce	Bandra">	
<option value="Sterling Institute of Management Studies	Nerul">	
<option value="Sudhagad Education Society?s Shikshan Maharshi Dadaseheb Limaye Arts	Kalamboli	">
<option value="Sultan Khan Educational Trust?s Asmita College of Architecture	Mira Road">	
<option value="Suman Education Trust, Dilkap Research Institute of Engineeing & Management Studies	Neral">	
<option value="Terna Public Charitable Trust?s Terna College of Engineering	Nerul	">
<option value="Thadomal Shahani Engineering College	Bandra	">
<option value="Thakur College of Aviation	Kandivali	Aviation">
<option value="Thakur College of Engineering & Technology	Kandivali	">
<option value="Thakur Education Trust?s Thakur Ramnarayan College of Law	Kandivali	">
<option value="Thakur Educational Trust's Thakur College of Science and Commerce	Kandivali">	
<option value="Thakur Educational Trust's Thakur Institute of Management Studies	Kandivali">	
<option value="Thane Zilla Agri Shikshan Prasarak Mandal`s Pragati College of Arts and Commerce	Dombivli">	
<option value="The B.P.C.A's College of Physical Education, Wadala">		
<option value="The Bassein Gujarathi Education Society`s Shah Khimchand Bhai Muljibhai College of Commerce	Vasai">	
<option value="The Bombay flying Club Juhu Arodrome	Juhu">	
<option value="The Bombay Salesian Society?s Don Bosco College	Kurla">	
<option value="The Bombay Salesian Society's Don Bosco Institute of Technology	Kurla">	
<option value="The Bombay St. Xavier?s College Society?s Xavier?s Institute of Management	Fort">	
<option value="The Bombay Xavierian Corporation Pvt. Ltd.?s College of Engineering	Mahim">	
<option value="The Borivli Education Society's Matushri Pushpaben Valia  College of Commerce	Borivali">	
<option value="The Byramjee Jeejeebhoy Parsee Charitable Trust College of Commerce	Charni Road">	
<option value="The C.E.O. Nagar Yuvak Shikshan Sanstha's, New Horizon College of Commerce	Airoli">	
<option value="The East Kalyan Welfare Society`s Model College of Science & Commerce	Kalyan">	
<option value="The Gurunanak Institute of Management Studies for M.M.S.	Matunga">	
<option value="The Gurunanak Vidyak Society's College of Arts, Science and Commerce	Sion">	
<option value="The Institute of Science, Fort">	
<option value="The Janseva Shikshan Mandal's Arts, Commerce & Science College	Murbad">	
<option value="The Kandivali Edcuation Society�s, Law College	Kandivali">	
<option value="The Kandivli Education Society's  Bhanumati Kishandas Shroff of Arts 
              and Maganlal Hargovinddas Shroff College of Commerce	Kandivali">	

<option value="The Kelkar Education Trust's Vinayak Ganesh Vaze College of Arts, Science and Commerce	Mulund">	
<option value="The Konkan Muslim Education Society's G.M.Momin Womens's College	Bhiwandi">	
<option value="The Sarvajanik Shikshan Sanstha College of Commerce	Mulund">	
<option value="The South Indian Education Society's College of Commerce, and Economics	Sion">	
<option value="The Taheri Scholarship Soceity?s BES?s Institute of Management Studies and Research	Mazgaon	">
<option value="Tilak Education Society`s College of Arts & Commerce	Vashi">	
<option value="Tilak Education Society?s J.K. College of Science & Commerce	Nerul">	
<option value="Tolani College of Commerce	Andheri	">
<option value="Training Ship Chanakya Government of India Ministry of Surface Transport Karave	Nerul">	
<option value="Ujwal Shikshan Sanstha?s College of Computer Science & Information Technology	Kandivali">	
<option value="Uran Education Society?s College of B.Sc.(I.T.)	Uran">	
<option value="V. K. Krishna  Menon College of Commerce and Economics	Bhandup">	
<option value="Veer Wajekar Arts, Science and Commerce College	Uran">	
<option value="Veermata Jijabai Technological Institute	Matunga	">
<option value="Versova Education Trust's Smt. Kamala Mehta, V.W.A. College of Commerce	Andheri">	
<option value="Vidya Prasarak Mandal?s Dr. V.N. Bedekar Institute of Management Studies	Thane">	
<option value="Vidya Prasarak Mandal?s Thane Municipal Council Law College	Thane">	
<option value="Vidya Prasarak Mandal?s, Kinhavali?Arts, Science and Commerce  College	Shahapur">	
<option value="Vidya Prasarak Mandal's K.G.Joshi College of Arts & N.G.Bedekar College of  Commerce	Thane">	
<option value="Vidya Vikas Education Society's Vikas Night College of Arts, Science and Commerce	Vikhroli">	
<option value="Vidya Vikas Education Trust, College of Arts, Com., Sci., B.M.M. & B.M.S	Goregaon">	
<option value="Vidya Vikas Education Trust, Universal College of Engineering	Vasai">	
<option value="Vidyalankar Danyanpeeth Trust College of B.Sc.(I.T.) Wadala">	
<option value="Vidyalankar Institute of Technology	Wadala">	


<option value="Vidyavardhini?s College of Engineering and Technology	Vasai">	

<option value="Vighnaharta Trust?s Shivajirao S. Jondhale College of Engineering & Technology	Asangaon">	
<option value="Vighnahartha Trust?s Shivajirao S. Jondhale College of Pharmacy	Asangaon">	

<option value="Vishnu Waman Thakur Charitable Trust, Viva Institute Applied Art (Art & Craft)	Virar">	
<option value="Vishnu Waman Thakur Charitable Trust?s M.M.S. Degree College,	Virar">	

<option value="Vishwatmak Om Gurudev College of Engineering	Shahapur">	
<option value="Vishweshwar Education Society?s Indra Institute of Business Management	Sanpada	">
<option value="Vishweshwar Education Society's Western College of Commerce & Business Management	Sanpada">	

<option value="Vivek Education Society's Arts & Commerce College	Goregaon">	

<option value="Vivekanand Education Society?s Institute of Technology	Chembur">	

<option value="Vivekanand Education Society's College of Arts, Science and Commerce	Chembur	">
<option value="Vivekanand Education Society's College of Law">	

<option value="VPM?s Ramniklal  Z. Shah College of Arts, Science and Commerce	Mulund">	

<option value="Watumall Institute of Electronic Engineering and Computer Technology	Worli">
<option value="Western Naval Command College of B.Sc. Hospitality Studies	Colaba">	
<option value="Wilson College	Girgaon	">
<option value="Yerla Medical Trust and Research Centre?s College of Management	Kharghar">	
<option value="Zagdu Singh Charitable Trust College of MMS	Kandivali">	

</datalist></td></tr>



<tr>
						<td>Branch: </td>
						
							<td align="left"> 
                                                  <input type="text" name="branch" id="branch" list="branches" required="required" value="<?php if(isset($_GET['branch'])) echo $_GET['branch'];?>"> 
                                                    <datalist id="branches"> 
													
													<option value="Hospitality Studies"></option>
                    <option value="Drawing and Painting"></option>                                <option value="Law"></option>
<option value="MCA"></option>
<option value="Aviation"></option>
<option value="Pharmacy"></option>
<option value="Nautical Science"></option>	
<option value="Physical Education"></option>
<option value="Maritime Science"></option>	
	<option value="Architechture"></option>	
	<option value="Heritage Management"></option>	
	<option value="Home Science"></option>	
	<option value="Social worker"></option>	
	
													
													
					           <option value="Science"></option>
							    <option value="Commerce"></option>
								 <option value="Arts"></option>
                                 <option value="Management Studies"></option>
                                <option value="Mechanical"></option>
                                <option value="Civil"></option>
                                <option value="Chemical"></option>
                                <option value="Computers"></option>
                                <option value="Information Technology (IT)/Information Science (IS)"></option>
                                <option value="Electrical/EEE"></option>
                                <option value="Electronics/ECE"></option>
                                <option value="Electronics &amp; Telecommunication"></option>
                                <option value="Production/Industrial Engg &amp; Mgmt"></option>
                                <option value="Biomedical/Medical Electronics"></option>
                                <option value="Instrumentation"></option>
                                <option value="Automobile"></option>
                                <option value="Bio-Technology"></option>
                                <option value="Textile"></option>
                                <option value="Marine"></option>
							</datalist>
						</td>
					</tr>





<tr>
						<td colspan="2"><center><input type="submit" style="width:150px;"></center></td>
					</tr>
					</center>
				</tbody></table>
			</form>
            </article>
        <article class="span3">
              <?php include "advertisements.php";?>
            </article>
      </div>
        </div>
  </div>
    </div>

<!--============================== footer =================================-->
<footer>
      <?php include "footer.php";?>
    </footer>
<script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html>						