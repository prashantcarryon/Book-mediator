<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
	<head>
	<title>Books</title>
	<meta charset="utf-8">
	<link rel="icon" href="img/favicon.png" type="image/x-icon">
	<link rel="shortcut icon" href="img/favicon.png" type="image/x-icon" />
	<meta name="description" content="Your description">
	<meta name="keywords" content="Your keywords">
	<meta name="author" content="Your name">
	<link rel="stylesheet" href="css/bootstrap.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/responsive.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300' rel='stylesheet' type='text/css'>
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/superfish.js"></script>
    <script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
	<script type="text/javascript">if($(window).width()>1024){document.write("<"+"script src='js/jquery.preloader.js'></"+"script>");}	</script>
	<script>		
		 jQuery(window).load(function() {	
		 $x = $(window).width();		
	if($x > 1024)
	{			
	jQuery("#content .row").preloader();    }			 
		
		 jQuery('.spinner').animate({'opacity':0},1000,'easeOutCubic',function (){jQuery(this).css('display','none')});	
  		  }); 
					
	</script>

	<!--[if lt IE 8]>
  		<div style='text-align:center'><a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.com/img/upgrade.jpg"border="0"alt=""/></a></div>  
 	<![endif]-->
	<!--[if (gt IE 9)|!(IE)]><!-->
	<!--<![endif]-->
	<!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>  
    <link rel="stylesheet" href="css/ie.css" type="text/css" media="screen">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400' rel='stylesheet' type='text/css'>
  <![endif]-->
	</head>

	<body>
<div class="spinner"></div>
<!--============================== header =================================-->
<header>
     <div class="container clearfix">
    <div class="row">
          <div class="span12">
        <div class="navbar navbar_">
              <div class="container">
            <h1 class="brand brand_"><a href="index.php"><img alt="" src="img/logo.png" width="500" height="200"> </a></h1>
            <a class="btn btn-navbar btn-navbar_" data-toggle="collapse" data-target=".nav-collapse_">Menu <span class="icon-bar"></span> </a>
            <div class="nav-collapse nav-collapse_  collapse">
                  <ul class="nav sf-menu">
                <li><a href="index.php">Home</a></li>
                <li class="sub-menu active"><a href="books.php">Books</a>
                      <ul style="z-index:100;">
                    <li><a href="books.php">Engineering </a></li>
                    <li><a href="books.php">Medical</a></li>
                    <li><a href="books.php">Commerce</a></li>
					<li><a href="books.php">Arts</a></li>
                  </ul>
                    </li>
                <li><a href="articles.php">Articles</a></li>
                <li><a href="sponsors.php">Sponsors</a></li>
                <li><a href="contact.php">Contact</a></li>
				<?php
				if(ISSET($_SESSION['username']))
				{ ?>
				<li id = "6"><a href="logout.php">Logout</a></li>
				<?php } 
				else
				{
				?>
				<li id = "6"><a href="login.php#tologin">Login</a></li>
				<?php } ?>
              </ul>
                </div>
          </div>
            </div>
      </div>
        </div>
  </div>
    </header>
<div class="bg-content"> 
      
      <!--============================== content =================================-->
      
    <div class="container">
          <div class="row">
        <article class="span12">
              <h3>Book Zone</h3>
            </article>
			
        <div class="clear"></div>

        <ul class="thumbnails thumbnails-1 list-services">
              <li class="span4">
            <div class="thumbnail thumbnail-1"> <img  src="img/page2-img1.jpg" alt="">
                  <section> <a href="#" class="link-1">At vero eos et accusamus et iusto </a>
                <p>Deleniti atque corrupti quos dolores molestias excepturi sint occaecati cupiditate nonprovident similique sunt in culpa.</p>
              </section>
                </div>
          </li>
              <li class="span4">
            <div class="thumbnail thumbnail-1"> <img  src="img/page2-img2.jpg" alt="">
                  <section> <a href="#" class="link-1">At vero eos et accusamus et iusto </a>
                <p>Deleniti atque corrupti quos dolores molestias excepturi sint occaecati cupiditate nonprovident similique sunt in culpa.</p>
              </section>
                </div>
          </li>
              <li class="span4">
            <div class="thumbnail thumbnail-1"> <img  src="img/page2-img3.jpg" alt="">
                  <section> <a href="#" class="link-1">At vero eos et accusamus et iusto </a>
                <p>Deleniti atque corrupti quos dolores molestias excepturi sint occaecati cupiditate nonprovident similique sunt in culpa.</p>
              </section>
                </div>
          </li>
              <li class="span4">
            <div class="thumbnail thumbnail-1"> <img  src="img/page2-img4.jpg" alt="">
                  <section> <a href="#" class="link-1">At vero eos et accusamus et iusto </a>
                <p>Deleniti atque corrupti quos dolores molestias excepturi sint occaecati cupiditate nonprovident similique sunt in culpa.</p>
              </section>
                </div>
          </li>
              <li class="span4">
            <div class="thumbnail thumbnail-1"> <img  src="img/page2-img5.jpg" alt="">
                  <section> <a href="#" class="link-1">At vero eos et accusamus et iusto </a>
                <p>Deleniti atque corrupti quos dolores molestias excepturi sint occaecati cupiditate nonprovident similique sunt in culpa.</p>
              </section>
                </div>
          </li>
              <li class="span4">
            <div class="thumbnail thumbnail-1"> <img  src="img/page2-img6.jpg" alt="">
                  <section> <a href="#" class="link-1">At vero eos et accusamus et iusto </a>
                <p>Deleniti atque corrupti quos dolores molestias excepturi sint occaecati cupiditate nonprovident similique sunt in culpa.</p>
              </section>
                </div>
          </li>
            </ul>
			<article class="span8">
             <?php include "advertisements.php";?>
            </article>
      </div>
        </div>
  </div>
    </div>

<!--============================== footer =================================-->
<footer>
     <?php include "footer.php";?>
    </footer>
<script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html>